# run_script.py
import sys

if __name__ == "__main__":
    print("Hello from inside Docker!")
    print("Arguments passed:", sys.argv[1:])
